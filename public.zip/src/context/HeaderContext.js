import { createContext } from "react";

const HeaderContext = createContext();

export default HeaderContext;